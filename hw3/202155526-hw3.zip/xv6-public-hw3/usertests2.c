#include "types.h"
#include "stat.h"
#include "user.h"

int
main(void)
{
    char *new_heap;
    
    printf(1, "Echo Test for Lazy Allocation: Starting\n");

    // Allocate new heap memory
    new_heap = (char*) sbrk(4096); // Increase heap size by 1 page (4KB)
    if (new_heap == (char*) -1) {
        printf(1, "sbrk failed\n");
        exit();
    }
    printf(1, "sbrk succeeded, heap increased by 4096 bytes\n");

    // Access the new heap memory to trigger a page fault
    printf(1, "Attempting to access new heap memory to trigger page fault\n");
    new_heap[0] = 'A'; // This should trigger a page fault and allocate memory

    // Verify if the access was successful
    if (new_heap[0] == 'A') {
        printf(1, "Successfully accessed new heap memory and handled page fault\n");
    } else {
        printf(1, "Failed to access new heap memory\n");
    }

    printf(1, "Echo Test for Lazy Allocation: Completed\n");
    exit();
}

